# 1. Implement a recursive function to calculate the factorial of a given number


def fac_rec(n):
  if n == 0 or n == 1:
    return 1
  else:
    return n * fac_rec(n - 1)


number = int(input("enter your number"))
res = fac_rec(number)
print("the factorial of {} is {}".format(number, res))
